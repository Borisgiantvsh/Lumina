import 'package:flutter/material.dart';

import 'core/playback/player_controller.dart';
import 'sources/ytmusic/ytmusic_api.dart';
import 'ui/search_home.dart';
import 'ui/theme.dart';

class LuminaApp extends StatelessWidget {
  const LuminaApp({super.key, required this.controller, required this.api});

  final PlayerController controller;
  final YtMusicApi api;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lumina',
      debugShowCheckedModeBanner: false,
      theme: buildLuminaTheme(),
      home: SearchHome(controller: controller, api: api),
    );
  }
}
