import 'package:flutter/foundation.dart';

/// Codecs Lumina can label truthfully.
enum AudioCodec {
  opus('Opus'),
  aac('AAC'),
  vorbis('Vorbis'),
  mp3('MP3'),
  flac('FLAC'),
  alac('ALAC'),
  pcm('PCM'),
  unknown('Audio');

  const AudioCodec(this.label);

  final String label;

  /// True only for codecs that are lossless by definition. A stream is never
  /// "upgraded" to lossless by a label: it either is one of these or it isn't.
  bool get isLossless => this == flac || this == alac || this == pcm;

  static AudioCodec parse(String? raw) {
    final c = (raw ?? '').toLowerCase();
    if (c.contains('opus')) return opus;
    if (c.contains('mp4a') || c.contains('aac')) return aac;
    if (c.contains('vorbis')) return vorbis;
    if (c.contains('mp3') || c.contains('mpeg')) return mp3;
    if (c.contains('flac')) return flac;
    if (c.contains('alac')) return alac;
    if (c.contains('pcm') || c.contains('wav')) return pcm;
    return unknown;
  }
}

/// A resolved, directly playable audio stream.
@immutable
class AudioStream {
  const AudioStream({
    required this.url,
    required this.codec,
    required this.bitrateKbps,
    required this.expiresAt,
    this.sampleRateHz,
    this.bitDepth,
    this.container,
    this.headers = const {},
    this.source = 'unknown',
  });

  final Uri url;
  final AudioCodec codec;
  final int bitrateKbps;
  final DateTime expiresAt;
  final int? sampleRateHz;
  final int? bitDepth;
  final String? container;
  final Map<String, String> headers;

  /// Which resolver produced this stream (for debugging).
  final String source;

  bool get isLossless => codec.isLossless;

  /// Signed URLs expire; anything close to expiry counts as stale.
  bool isFresh({Duration margin = const Duration(minutes: 10)}) =>
      DateTime.now().isBefore(expiresAt.subtract(margin));

  /// Truthful label, e.g. "Opus 160 kbps" or "Lossless FLAC 24-bit/96 kHz".
  String get qualityLabel {
    if (isLossless) {
      final depth = bitDepth;
      final rate = sampleRateHz;
      final detail = depth != null && rate != null ? ' $depth-bit/${_khz(rate)} kHz' : '';
      return 'Lossless ${codec.label}$detail';
    }
    return bitrateKbps > 0 ? '${codec.label} $bitrateKbps kbps' : codec.label;
  }

  static String _khz(int hz) {
    final k = hz / 1000;
    return k == k.roundToDouble() ? k.round().toString() : k.toStringAsFixed(1);
  }

  /// googlevideo URLs carry their expiry as `expire=<unix seconds>`.
  static DateTime expiryFromUrl(Uri url, {Duration fallback = const Duration(hours: 5)}) {
    final seconds = int.tryParse(url.queryParameters['expire'] ?? '');
    if (seconds == null) return DateTime.now().add(fallback);
    return DateTime.fromMillisecondsSinceEpoch(seconds * 1000);
  }
}
