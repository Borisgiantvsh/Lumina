import 'package:flutter/foundation.dart';

@immutable
class LyricLine {
  const LyricLine(this.start, this.text);

  final Duration start;
  final String text;
}

@immutable
class Lyrics {
  const Lyrics({required this.lines, required this.synced, this.source});

  final List<LyricLine> lines;

  /// True when every line carries a timestamp.
  final bool synced;

  /// Where the lyrics came from (shown as attribution).
  final String? source;

  bool get isEmpty => lines.isEmpty;

  factory Lyrics.plain(String text, {String? source}) => Lyrics(
        lines: [for (final line in text.split('\n')) LyricLine(Duration.zero, line.trim())],
        synced: false,
        source: source,
      );

  /// Parses LRC (`[mm:ss.xx] text`). Lines may carry several timestamps and
  /// metadata tags such as `[ar:Artist]` are ignored.
  factory Lyrics.fromLrc(String lrc, {String? source}) {
    final tag = RegExp(r'\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]');
    final lines = <LyricLine>[];
    for (final raw in lrc.split('\n')) {
      final matches = tag.allMatches(raw).toList();
      if (matches.isEmpty) continue;
      final text = raw.substring(matches.last.end).trim();
      for (final m in matches) {
        final minutes = int.parse(m.group(1)!);
        final seconds = int.parse(m.group(2)!);
        final fraction = m.group(3);
        final millis = fraction == null ? 0 : int.parse(fraction.padRight(3, '0').substring(0, 3));
        lines.add(LyricLine(
          Duration(minutes: minutes, seconds: seconds, milliseconds: millis),
          text,
        ));
      }
    }
    lines.sort((a, b) => a.start.compareTo(b.start));
    return Lyrics(lines: lines, synced: lines.isNotEmpty, source: source);
  }

  /// Index of the line being sung at [position], or -1 before the first line.
  int indexAt(Duration position) {
    var lo = 0;
    var hi = lines.length - 1;
    var answer = -1;
    while (lo <= hi) {
      final mid = (lo + hi) >> 1;
      if (lines[mid].start <= position) {
        answer = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    return answer;
  }
}
