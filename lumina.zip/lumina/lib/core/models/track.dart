import 'package:flutter/foundation.dart';

/// A playable item. [id] is the YouTube video id and doubles as the cache key
/// everywhere (stream cache, SponsorBlock, LRCLIB lookups, disk cache).
@immutable
class Track {
  const Track({
    required this.id,
    required this.title,
    required this.artist,
    this.album,
    this.duration,
    this.artworkUrl,
  });

  final String id;
  final String title;
  final String artist;
  final String? album;
  final Duration? duration;
  final String? artworkUrl;

  /// YouTube Music thumbnails carry their size in the URL (`=w226-h226-l90-rj`).
  /// Rewriting it gives a sharp image without another API call.
  String? artwork({int size = 1024}) {
    final url = artworkUrl;
    if (url == null) return null;
    return url.replaceFirstMapped(RegExp(r'=w\d+-h\d+'), (_) => '=w$size-h$size');
  }

  @override
  bool operator ==(Object other) => other is Track && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
