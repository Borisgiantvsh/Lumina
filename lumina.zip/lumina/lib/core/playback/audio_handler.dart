import 'package:audio_service/audio_service.dart';

import '../models/track.dart';
import 'player_controller.dart';

/// Thin adapter between [PlayerController] and the OS: lock-screen and
/// notification controls, headset buttons, and the Android Auto browse tree.
class LuminaAudioHandler extends BaseAudioHandler with SeekHandler {
  LuminaAudioHandler(this._c, {required this.searchTracks}) {
    _c.addListener(_sync);
    _c.duration.addListener(_syncDuration);
    _sync();
  }

  final PlayerController _c;
  final Future<List<Track>> Function(String query) searchTracks;

  Track? _lastTrack;

  static const _queueId = 'lumina.queue';
  static const _recentId = 'lumina.recent';

  // ---- state sync ---------------------------------------------------------

  void _sync() {
    final track = _c.current;
    if (track != _lastTrack) {
      _lastTrack = track;
      mediaItem.add(track == null ? null : _toItem(track, duration: _c.duration.value));
      queue.add([for (final t in _c.queue) _toItem(t)]);
    }

    playbackState.add(PlaybackState(
      controls: [
        MediaControl.skipToPrevious,
        if (_c.isPlaying) MediaControl.pause else MediaControl.play,
        MediaControl.skipToNext,
      ],
      systemActions: const {
        MediaAction.seek,
        MediaAction.seekForward,
        MediaAction.seekBackward,
      },
      androidCompactActionIndices: const [0, 1, 2],
      processingState: _c.error != null
          ? AudioProcessingState.error
          : _c.current == null
              ? AudioProcessingState.idle
              : _c.isBusy
                  ? AudioProcessingState.loading
                  : AudioProcessingState.ready,
      playing: _c.isPlaying,
      updatePosition: _c.position.value,
      speed: 1.0,
      queueIndex: _c.queueIndex,
    ));
  }

  void _syncDuration() {
    final item = mediaItem.value;
    final d = _c.duration.value;
    if (item != null && d > Duration.zero && item.duration != d) {
      mediaItem.add(item.copyWith(duration: d));
    }
  }

  MediaItem _toItem(Track t, {Duration? duration}) {
    final art = t.artwork(size: 544);
    return MediaItem(
      id: t.id,
      title: t.title,
      artist: t.artist,
      album: t.album,
      duration: duration ?? t.duration,
      artUri: art == null ? null : Uri.parse(art),
    );
  }

  // ---- transport ----------------------------------------------------------

  @override
  Future<void> play() => _c.play();

  @override
  Future<void> pause() => _c.pause();

  @override
  Future<void> seek(Duration position) => _c.seek(position);

  @override
  Future<void> skipToNext() => _c.next();

  @override
  Future<void> skipToPrevious() => _c.previous();

  @override
  Future<void> skipToQueueItem(int index) => _c.playIndex(index);

  @override
  Future<void> stop() async {
    await _c.stop();
    await super.stop();
  }

  @override
  Future<void> onTaskRemoved() => stop();

  // ---- Android Auto browse tree and voice commands --------------------------

  @override
  Future<List<MediaItem>> getChildren(String parentMediaId, [Map<String, dynamic>? options]) async {
    switch (parentMediaId) {
      case AudioService.browsableRootId:
        return [
          const MediaItem(id: _queueId, title: 'Up next', playable: false),
          const MediaItem(id: _recentId, title: 'Recently played', playable: false),
        ];
      case _queueId:
        return [for (final t in _c.queue) _toItem(t)];
      case _recentId:
        return [for (final t in _c.recent) _toItem(t)];
      default:
        return const [];
    }
  }

  @override
  Future<void> playFromMediaId(String mediaId, [Map<String, dynamic>? extras]) async {
    final inQueue = _c.queue.indexWhere((t) => t.id == mediaId);
    if (inQueue >= 0) return _c.playIndex(inQueue);

    final recent = _c.recent;
    final inRecent = recent.indexWhere((t) => t.id == mediaId);
    if (inRecent >= 0) return _c.playQueue(recent, startIndex: inRecent);
  }

  @override
  Future<void> playFromSearch(String query, [Map<String, dynamic>? extras]) async {
    final results = await searchTracks(query);
    if (results.isNotEmpty) await _c.playQueue(results);
  }

  @override
  Future<List<MediaItem>> search(String query, [Map<String, dynamic>? extras]) async {
    final results = await searchTracks(query);
    return [for (final t in results) _toItem(t)];
  }
}
