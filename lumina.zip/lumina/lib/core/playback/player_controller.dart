import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import '../../sources/ytmusic/stream_resolver.dart';
import '../models/audio_stream.dart';
import '../models/lyrics.dart';
import '../models/track.dart';
import '../plugin/plugin.dart';
import '../plugin/plugin_host.dart';

enum RepeatMode { off, all, one }

/// Builds the just_audio source for a resolved stream. Replace this to add
/// disk caching (for example LockCachingAudioSource) without touching the
/// controller.
typedef AudioSourceFactory = Future<AudioSource> Function(Track track, AudioStream stream);

/// Platform-agnostic playback brain. The UI and the Android audio_service
/// handler both talk to this; it talks to just_audio, the resolver and plugins.
class PlayerController extends ChangeNotifier {
  PlayerController({
    required this.resolver,
    required this.plugins,
    AudioPlayer? player,
    AudioSourceFactory? sourceFactory,
  })  : _player = player ?? AudioPlayer(),
        _sourceFactory = sourceFactory ?? _defaultSource {
    _wire();
  }

  static Future<AudioSource> _defaultSource(Track track, AudioStream stream) async =>
      AudioSource.uri(stream.url, headers: stream.headers.isEmpty ? null : stream.headers);

  final StreamResolver resolver;
  final PluginHost plugins;
  final AudioPlayer _player;
  final AudioSourceFactory _sourceFactory;

  final _rng = math.Random();
  final _subscriptions = <StreamSubscription<Object?>>[];
  final _toastController = StreamController<String>.broadcast();

  /// Updated several times a second. Listen to these (not the controller) for
  /// scrubbers and lyrics.
  final position = ValueNotifier<Duration>(Duration.zero);
  final duration = ValueNotifier<Duration>(Duration.zero);

  /// Short messages for the UI, such as "Skipped sponsor".
  Stream<String> get toasts => _toastController.stream;

  // ---- state ----------------------------------------------------------------

  List<Track> _queue = const [];
  List<int> _order = const []; // play order, as indices into _queue
  int _cursor = -1; // position within _order
  final _recent = <Track>[];

  AudioStream? _stream;
  Lyrics? _lyrics;
  List<TrackBadge> _badges = const [];
  List<SkipSegment> _segments = const [];
  final _skipped = <String>{};

  bool _playing = false;
  bool _loading = false;
  bool _autoplay = false;
  bool _lyricsLoading = false;
  bool _retriedMidStream = false;
  ProcessingState _processing = ProcessingState.idle;
  RepeatMode _repeat = RepeatMode.off;
  bool _shuffle = false;
  String? _error;
  int _token = 0;

  Track? get current => _cursor >= 0 && _cursor < _order.length ? _queue[_order[_cursor]] : null;
  int? get queueIndex => _cursor >= 0 && _cursor < _order.length ? _order[_cursor] : null;
  List<Track> get queue => _queue;
  List<Track> get recent => List.unmodifiable(_recent);
  AudioStream? get stream => _stream;
  Lyrics? get lyrics => _lyrics;
  bool get lyricsLoading => _lyricsLoading;
  List<TrackBadge> get badges => _badges;
  String? get error => _error;
  RepeatMode get repeat => _repeat;
  bool get shuffle => _shuffle;

  /// True while audio is playing or about to (resolving a track with autoplay).
  bool get isPlaying => _playing || (_loading && _autoplay);

  /// True while resolving a stream or while the player is loading/buffering.
  bool get isBusy =>
      _loading ||
      _processing == ProcessingState.loading ||
      _processing == ProcessingState.buffering;

  // ---- commands -------------------------------------------------------------

  Future<void> playQueue(List<Track> tracks, {int startIndex = 0}) async {
    if (tracks.isEmpty) return;
    _queue = List.of(tracks);
    _autoplay = true;
    _rebuildOrder(startAt: math.min(math.max(startIndex, 0), tracks.length - 1));
    await _start();
  }

  Future<void> playTrack(Track track) => playQueue([track]);

  Future<void> playIndex(int queueIndex) async {
    if (queueIndex < 0 || queueIndex >= _queue.length) return;
    _autoplay = true;
    _rebuildOrder(startAt: queueIndex);
    await _start();
  }

  Future<void> play() async {
    if (current == null) return;
    _autoplay = true;
    if (_stream == null && !_loading) {
      await _start(); // the last attempt failed; try again
      return;
    }
    if (_processing == ProcessingState.completed) await _player.seek(Duration.zero);
    unawaited(_player.play());
    notifyListeners();
  }

  Future<void> pause() async {
    _autoplay = false;
    await _player.pause();
    notifyListeners();
  }

  Future<void> togglePlay() => isPlaying ? pause() : play();

  Future<void> stop() async {
    _autoplay = false;
    _token++;
    _loading = false;
    await _player.stop();
    notifyListeners();
  }

  Future<void> seek(Duration to) async {
    final total = duration.value;
    var target = to < Duration.zero ? Duration.zero : to;
    if (total > Duration.zero && target > total) target = total;
    position.value = target;
    await _player.seek(target);
    notifyListeners();
    _emitPlayback();
  }

  Future<void> next() async {
    if (_order.isEmpty) return;
    if (_cursor + 1 < _order.length) {
      _cursor++;
    } else if (_repeat == RepeatMode.all) {
      _cursor = 0;
    } else {
      _autoplay = false; // end of the queue
      await _player.pause();
      await seek(Duration.zero);
      return;
    }
    await _start();
  }

  Future<void> previous() async {
    if (_order.isEmpty) return;
    if (position.value > const Duration(seconds: 3) ||
        (_cursor == 0 && _repeat != RepeatMode.all)) {
      await seek(Duration.zero);
      return;
    }
    _cursor = _cursor > 0 ? _cursor - 1 : _order.length - 1;
    await _start();
  }

  void toggleShuffle() {
    final currentIndex = queueIndex ?? 0;
    _shuffle = !_shuffle;
    if (_queue.isNotEmpty) _rebuildOrder(startAt: currentIndex);
    notifyListeners();
  }

  void cycleRepeat() {
    _repeat = RepeatMode.values[(_repeat.index + 1) % RepeatMode.values.length];
    notifyListeners();
  }

  // ---- internals ------------------------------------------------------------

  void _wire() {
    _subscriptions.addAll([
      _player.playerStateStream.listen(_onPlayerState),
      _player.positionStream.listen(_onPosition),
      _player.durationStream.listen((d) {
        if (d != null && d > Duration.zero) duration.value = d;
      }),
      _player.playbackEventStream.listen(
        (_) {},
        onError: (Object error, StackTrace _) => _onPlayerError(error),
      ),
    ]);
  }

  void _rebuildOrder({required int startAt}) {
    final indices = List<int>.generate(_queue.length, (i) => i);
    if (_shuffle) {
      indices.remove(startAt);
      indices.shuffle(_rng);
      _order = [startAt, ...indices];
      _cursor = 0;
    } else {
      _order = indices;
      _cursor = startAt;
    }
  }

  Future<void> _start({Duration? resumeAt}) async {
    final track = current;
    if (track == null) return;
    final token = ++_token;

    unawaited(_player.pause()); // silence the old track while the new one resolves
    _stream = null;
    _lyrics = null;
    _lyricsLoading = true;
    _badges = const [];
    _segments = const [];
    _skipped.clear();
    _error = null;
    _loading = true;
    if (resumeAt == null) _retriedMidStream = false;
    position.value = resumeAt ?? Duration.zero;
    duration.value = track.duration ?? Duration.zero;
    _remember(track);
    notifyListeners();

    try {
      final stream = await _prepare(track, token, resumeAt);
      if (stream == null || token != _token) return;
      _stream = stream;
      _loading = false;
      notifyListeners();

      if (_autoplay) unawaited(_player.play());
      plugins.trackChanged(track, stream);
      unawaited(_loadPluginData(track, stream, token));
      unawaited(_prefetchNext());
    } catch (error) {
      if (token != _token) return;
      _loading = false;
      _lyricsLoading = false;
      _error = 'Couldn\u2019t load audio for this track. Check your connection, then tap play to retry.';
      plugins.context.log('player', 'start failed: $error');
      notifyListeners();
    }
  }

  /// Resolves and loads the stream, retrying once with a fresh URL because
  /// signed URLs expire and cached ones can go stale.
  Future<AudioStream?> _prepare(Track track, int token, Duration? resumeAt) async {
    for (var attempt = 0;; attempt++) {
      try {
        final stream = await resolver.resolve(track.id);
        if (token != _token) return null;
        final source = await _sourceFactory(track, stream);
        await _player.setAudioSource(source, initialPosition: resumeAt);
        if (token != _token) return null;
        return stream;
      } on PlayerInterruptedException {
        return null; // a newer request replaced this one
      } catch (_) {
        if (token != _token) return null;
        if (attempt >= 1) rethrow;
        resolver.invalidate(track.id);
      }
    }
  }

  Future<void> _loadPluginData(Track track, AudioStream stream, int token) async {
    unawaited(plugins.segmentsFor(track).then((segments) {
      if (token == _token) _segments = segments;
    }));
    unawaited(plugins.badgesFor(track, stream).then((badges) {
      if (token != _token) return;
      _badges = badges;
      notifyListeners();
    }));

    final lyrics = await plugins.lyricsFor(track);
    if (token != _token) return;
    _lyrics = lyrics;
    _lyricsLoading = false;
    notifyListeners();
  }

  Future<void> _prefetchNext() async {
    final i = _cursor + 1;
    if (i >= _order.length) return;
    try {
      await resolver.resolve(_queue[_order[i]].id); // warms the resolver cache
    } catch (_) {
      // best effort
    }
  }

  void _remember(Track track) {
    _recent
      ..removeWhere((t) => t.id == track.id)
      ..insert(0, track);
    if (_recent.length > 30) _recent.removeRange(30, _recent.length);
  }

  void _onPlayerState(PlayerState state) {
    final changed = state.playing != _playing || state.processingState != _processing;
    _playing = state.playing;
    _processing = state.processingState;
    if (state.processingState == ProcessingState.completed) _onCompleted();
    if (changed) {
      notifyListeners();
      _emitPlayback();
    }
  }

  void _onCompleted() {
    if (_repeat == RepeatMode.one) {
      unawaited(_replay());
    } else {
      unawaited(next());
    }
  }

  Future<void> _replay() async {
    await _player.seek(Duration.zero);
    unawaited(_player.play());
  }

  void _onPosition(Duration p) {
    position.value = p;
    if (_segments.isEmpty || _loading) return;
    for (final segment in _segments) {
      if (p >= segment.start && p < segment.end && _skipped.add(segment.id)) {
        _toastController.add('Skipped ${segment.label}');
        final total = duration.value;
        if (total > Duration.zero && segment.end >= total - const Duration(seconds: 1)) {
          unawaited(next());
        } else {
          unawaited(seek(segment.end));
        }
        return;
      }
    }
  }

  void _onPlayerError(Object error) {
    final track = current;
    if (_loading || track == null) return; // load errors are handled in _prepare
    if (_retriedMidStream) {
      _error = 'Playback stopped. Tap play to retry.';
      notifyListeners();
      return;
    }
    _retriedMidStream = true;
    resolver.invalidate(track.id);
    unawaited(_start(resumeAt: position.value));
  }

  void _emitPlayback() {
    plugins.playbackChanged(PlaybackSnapshot(
      track: current,
      playing: isPlaying,
      position: position.value,
      duration: duration.value,
    ));
  }

  @override
  void dispose() {
    for (final subscription in _subscriptions) {
      unawaited(subscription.cancel());
    }
    unawaited(_toastController.close());
    position.dispose();
    duration.dispose();
    unawaited(_player.dispose());
    super.dispose();
  }
}
