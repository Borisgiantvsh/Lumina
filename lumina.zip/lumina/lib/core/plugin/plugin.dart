import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart' show IconData;
import 'package:http/http.dart' as http;

import '../models/audio_stream.dart';
import '../models/lyrics.dart';
import '../models/track.dart';

/// Small key-value store handed to plugins for their settings.
/// Swap [MemoryPluginStorage] for a shared_preferences-backed one to persist.
abstract class PluginStorage {
  String? getString(String pluginId, String key);
  Future<void> setString(String pluginId, String key, String value);
}

class MemoryPluginStorage implements PluginStorage {
  final _values = <String, String>{};

  @override
  String? getString(String pluginId, String key) => _values['$pluginId/$key'];

  @override
  Future<void> setString(String pluginId, String key, String value) async {
    _values['$pluginId/$key'] = value;
  }
}

/// Everything a plugin is allowed to touch.
class PluginContext {
  PluginContext({
    required this.client,
    required this.storage,
    void Function(String message)? logger,
  }) : _logger = logger;

  final http.Client client;
  final PluginStorage storage;
  final void Function(String message)? _logger;

  void log(String pluginId, String message) => _logger?.call('[$pluginId] $message');
}

/// What a plugin sees on play, pause and seek (not on every position tick).
@immutable
class PlaybackSnapshot {
  const PlaybackSnapshot({
    required this.track,
    required this.playing,
    required this.position,
    required this.duration,
  });

  final Track? track;
  final bool playing;
  final Duration position;
  final Duration duration;
}

/// A span of the track the player should jump over.
@immutable
class SkipSegment {
  const SkipSegment({
    required this.id,
    required this.category,
    required this.label,
    required this.start,
    required this.end,
    this.source = '',
  });

  final String id;
  final String category;

  /// Human-readable, used in "Skipped <label>".
  final String label;
  final Duration start;
  final Duration end;
  final String source;
}

/// A small pill shown under the scrubber (quality, dislikes, ...).
@immutable
class TrackBadge {
  const TrackBadge({required this.id, required this.label, this.icon, this.tooltip});

  final String id;
  final String label;
  final IconData? icon;
  final String? tooltip;
}

enum VisualKind { video, image }

/// A looping visual for the Now Playing background (Canvas-style).
@immutable
class TrackVisual {
  const TrackVisual({required this.url, required this.kind, this.loop = true});

  final Uri url;
  final VisualKind kind;
  final bool loop;
}

/// Base class for every plugin.
///
/// A plugin extends this and also `implements` the capability interfaces it
/// supports ([SegmentProvider], [LyricsProvider], [BadgeProvider],
/// [VisualsProvider]). The [PluginHost] calls those capabilities, isolates
/// failures and applies timeouts, so a broken plugin can't stop playback.
///
/// ```dart
/// class MyPlugin extends LuminaPlugin implements BadgeProvider {
///   @override String get id => 'my-plugin';
///   @override String get name => 'My plugin';
///   @override
///   Future<List<TrackBadge>> badgesFor(Track track, AudioStream? stream) async =>
///       [TrackBadge(id: 'hello', label: track.title)];
/// }
/// ```
abstract class LuminaPlugin {
  /// Stable, unique id, for example `sponsorblock`.
  String get id;

  String get name;

  String get description => '';

  Future<void> attach(PluginContext context) async {}

  Future<void> detach() async {}

  /// A new track has been resolved and is about to play.
  void onTrackChanged(Track track, AudioStream? stream) {}

  /// Play, pause or seek happened.
  void onPlaybackChanged(PlaybackSnapshot snapshot) {}
}

abstract interface class SegmentProvider {
  Future<List<SkipSegment>> segmentsFor(Track track);
}

abstract interface class LyricsProvider {
  Future<Lyrics?> lyricsFor(Track track);
}

abstract interface class BadgeProvider {
  Future<List<TrackBadge>> badgesFor(Track track, AudioStream? stream);
}

abstract interface class VisualsProvider {
  Future<TrackVisual?> visualFor(Track track);
}
