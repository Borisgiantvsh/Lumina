import 'dart:async';

import 'package:flutter/foundation.dart';

import '../models/audio_stream.dart';
import '../models/lyrics.dart';
import '../models/track.dart';
import 'plugin.dart';

/// Owns every plugin. All calls into plugins are guarded: an exception or a
/// slow response is logged and replaced by an empty result.
class PluginHost extends ChangeNotifier {
  PluginHost(this.context);

  final PluginContext context;

  static const _timeout = Duration(seconds: 8);

  final _plugins = <String, LuminaPlugin>{};
  final _disabled = <String>{};

  List<LuminaPlugin> get plugins => List.unmodifiable(_plugins.values);

  bool isEnabled(String id) => _plugins.containsKey(id) && !_disabled.contains(id);

  Future<void> register(LuminaPlugin plugin) async {
    if (_plugins.containsKey(plugin.id)) {
      throw ArgumentError('A plugin with id "${plugin.id}" is already registered.');
    }
    _plugins[plugin.id] = plugin;
    try {
      await plugin.attach(context);
    } catch (error) {
      _disabled.add(plugin.id);
      context.log(plugin.id, 'attach failed, plugin disabled: $error');
    }
    notifyListeners();
  }

  void setEnabled(String id, {required bool enabled}) {
    if (enabled) {
      _disabled.remove(id);
    } else {
      _disabled.add(id);
    }
    notifyListeners();
  }

  // ---- capability aggregation ------------------------------------------

  /// Segments from every [SegmentProvider], sorted by start time.
  Future<List<SkipSegment>> segmentsFor(Track track) async {
    final lists = await Future.wait([
      for (final e in _providers<SegmentProvider>())
        _guard<List<SkipSegment>>(e.$1, 'segmentsFor', () => e.$2.segmentsFor(track), const []),
    ]);
    return [for (final list in lists) ...list]..sort((a, b) => a.start.compareTo(b.start));
  }

  /// First synced result wins; otherwise the first plain-text result.
  Future<Lyrics?> lyricsFor(Track track) async {
    Lyrics? fallback;
    for (final e in _providers<LyricsProvider>()) {
      final lyrics = await _guard<Lyrics?>(e.$1, 'lyricsFor', () => e.$2.lyricsFor(track), null);
      if (lyrics == null || lyrics.isEmpty) continue;
      if (lyrics.synced) return lyrics;
      fallback ??= lyrics;
    }
    return fallback;
  }

  /// Badges from every [BadgeProvider], in plugin registration order.
  Future<List<TrackBadge>> badgesFor(Track track, AudioStream? stream) async {
    final lists = await Future.wait([
      for (final e in _providers<BadgeProvider>())
        _guard<List<TrackBadge>>(e.$1, 'badgesFor', () => e.$2.badgesFor(track, stream), const []),
    ]);
    return [for (final list in lists) ...list];
  }

  Future<TrackVisual?> visualFor(Track track) async {
    for (final e in _providers<VisualsProvider>()) {
      final visual = await _guard<TrackVisual?>(e.$1, 'visualFor', () => e.$2.visualFor(track), null);
      if (visual != null) return visual;
    }
    return null;
  }

  // ---- event fan-out ----------------------------------------------------

  void trackChanged(Track track, AudioStream? stream) {
    for (final plugin in _enabled) {
      try {
        plugin.onTrackChanged(track, stream);
      } catch (error) {
        context.log(plugin.id, 'onTrackChanged failed: $error');
      }
    }
  }

  void playbackChanged(PlaybackSnapshot snapshot) {
    for (final plugin in _enabled) {
      try {
        plugin.onPlaybackChanged(snapshot);
      } catch (error) {
        context.log(plugin.id, 'onPlaybackChanged failed: $error');
      }
    }
  }

  // ---- internals --------------------------------------------------------

  Iterable<LuminaPlugin> get _enabled => _plugins.values.where((p) => !_disabled.contains(p.id));

  List<(LuminaPlugin, T)> _providers<T>() {
    final out = <(LuminaPlugin, T)>[];
    for (final plugin in _enabled) {
      final Object candidate = plugin;
      if (candidate is T) out.add((plugin, candidate));
    }
    return out;
  }

  Future<R> _guard<R>(
    LuminaPlugin plugin,
    String hook,
    Future<R> Function() body,
    R fallback,
  ) async {
    try {
      return await body().timeout(_timeout);
    } catch (error) {
      context.log(plugin.id, '$hook failed: $error');
      return fallback;
    }
  }

  @override
  void dispose() {
    for (final plugin in _plugins.values) {
      unawaited(plugin.detach().catchError((Object _) {}));
    }
    super.dispose();
  }
}
