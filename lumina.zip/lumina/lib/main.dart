import 'dart:io';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio_media_kit/just_audio_media_kit.dart';

import 'app.dart';
import 'core/playback/audio_handler.dart';
import 'core/playback/player_controller.dart';
import 'core/plugin/plugin.dart';
import 'core/plugin/plugin_host.dart';
import 'plugins/lrclib_lyrics_plugin.dart';
import 'plugins/return_dislike_plugin.dart';
import 'plugins/sound_quality_plugin.dart';
import 'plugins/sponsorblock_plugin.dart';
import 'sources/ytmusic/innertube_client.dart';
import 'sources/ytmusic/stream_resolver.dart';
import 'sources/ytmusic/youtube_explode_resolver.dart';
import 'sources/ytmusic/ytdlp_resolver.dart';
import 'sources/ytmusic/ytmusic_api.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final isDesktop = Platform.isWindows || Platform.isLinux || Platform.isMacOS;

  // Windows and Linux have no native just_audio backend; libmpv fills the gap.
  if (Platform.isWindows || Platform.isLinux) {
    JustAudioMediaKit.ensureInitialized();
  }

  final httpClient = http.Client();

  // Registration order is the display order of badges.
  final plugins = PluginHost(PluginContext(
    client: httpClient,
    storage: MemoryPluginStorage(),
    logger: debugPrint,
  ));
  await plugins.register(SoundQualityPlugin());
  await plugins.register(SponsorBlockPlugin());
  await plugins.register(ReturnDislikePlugin());
  await plugins.register(LrclibLyricsPlugin());

  final resolver = CachingResolver(
    FallbackResolver([
      // Dart-only extractor: works on every platform.
      // To enable the optional Deno JS solver on desktop, build a YoutubeExplode
      // with `jsSolver` (see the youtube_explode_dart README) and pass it as
      // `client:`.
      YoutubeExplodeResolver(preferAac: Platform.isIOS || Platform.isMacOS),
      // Desktop safety net: uses yt-dlp if it's on PATH.
      if (isDesktop) YtDlpResolver(),
    ]),
  );

  final controller = PlayerController(resolver: resolver, plugins: plugins);
  final api = YtMusicApi(InnertubeClient(httpClient: httpClient));

  // Background playback, notification/lock-screen controls and Android Auto.
  if (Platform.isAndroid || Platform.isIOS || Platform.isMacOS) {
    await AudioService.init(
      builder: () => LuminaAudioHandler(controller, searchTracks: api.searchSongs),
      config: const AudioServiceConfig(
        androidNotificationChannelId: 'app.lumina.playback',
        androidNotificationChannelName: 'Playback',
        androidNotificationOngoing: true,
      ),
    );
  }

  runApp(LuminaApp(controller: controller, api: api));
}
