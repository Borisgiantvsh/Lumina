import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/models/lyrics.dart';
import '../core/models/track.dart';
import '../core/plugin/plugin.dart';

/// Synced lyrics from LRCLIB (https://lrclib.net), a free, open lyrics API.
/// Falls back to a fuzzy search when the exact match misses.
class LrclibLyricsPlugin extends LuminaPlugin implements LyricsProvider {
  static const _host = 'lrclib.net';

  // LRCLIB asks clients to identify themselves. Put your repo URL here.
  static const _headers = {'User-Agent': 'Lumina/0.1.0 (https://github.com/your-name/lumina)'};

  late http.Client _client;

  @override
  String get id => 'lrclib';

  @override
  String get name => 'LRCLIB lyrics';

  @override
  String get description => 'Time-synced lyrics from LRCLIB.';

  @override
  Future<void> attach(PluginContext context) async {
    _client = context.client;
  }

  @override
  Future<Lyrics?> lyricsFor(Track track) async {
    final artist = _primaryArtist(track.artist);

    final exact = Uri.https(_host, '/api/get', {
      'track_name': track.title,
      'artist_name': artist,
      if (track.album != null) 'album_name': track.album!,
      if (track.duration != null) 'duration': '${track.duration!.inSeconds}',
    });
    final response = await _client.get(exact, headers: _headers);
    if (response.statusCode == 200) {
      return _fromJson(jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>);
    }
    if (response.statusCode != 404) return null;

    final search = Uri.https(_host, '/api/search', {
      'track_name': track.title,
      'artist_name': artist,
    });
    final fuzzy = await _client.get(search, headers: _headers);
    if (fuzzy.statusCode != 200) return null;

    final results =
        (jsonDecode(utf8.decode(fuzzy.bodyBytes)) as List).whereType<Map<String, dynamic>>().toList();
    Lyrics? plain;
    for (final result in results) {
      final lyrics = _fromJson(result);
      if (lyrics == null) continue;
      if (lyrics.synced) return lyrics;
      plain ??= lyrics;
    }
    return plain;
  }

  Lyrics? _fromJson(Map<String, dynamic> json) {
    if (json['instrumental'] == true) return null;
    final synced = json['syncedLyrics'];
    if (synced is String && synced.trim().isNotEmpty) {
      final lyrics = Lyrics.fromLrc(synced, source: 'LRCLIB');
      if (!lyrics.isEmpty) return lyrics;
    }
    final plain = json['plainLyrics'];
    if (plain is String && plain.trim().isNotEmpty) {
      return Lyrics.plain(plain, source: 'LRCLIB');
    }
    return null;
  }

  /// "A & B", "A, B" or "A feat. B" all match on the first artist.
  static String _primaryArtist(String artist) =>
      artist.split(RegExp(r'\s*(?:&|,|\bfeat\.?\b|\bft\.?\b)\s*', caseSensitive: false)).first.trim();
}
