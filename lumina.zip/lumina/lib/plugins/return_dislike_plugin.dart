import 'dart:convert';

import 'package:flutter/material.dart' show Icons;
import 'package:http/http.dart' as http;

import '../core/models/audio_stream.dart';
import '../core/models/track.dart';
import '../core/plugin/plugin.dart';

/// Shows like and dislike counts again, using the Return YouTube Dislike API.
/// Dislike counts are estimates reconstructed from extension users' data.
class ReturnDislikePlugin extends LuminaPlugin implements BadgeProvider {
  late http.Client _client;

  @override
  String get id => 'return-youtube-dislike';

  @override
  String get name => 'Return YouTube Dislike';

  @override
  String get description => 'Brings back like and dislike counts (dislikes are estimates).';

  @override
  Future<void> attach(PluginContext context) async {
    _client = context.client;
  }

  @override
  Future<List<TrackBadge>> badgesFor(Track track, AudioStream? stream) async {
    final uri = Uri.https('returnyoutubedislikeapi.com', '/votes', {'videoId': track.id});
    final response = await _client.get(uri);
    if (response.statusCode != 200) return const [];

    final json = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final likes = json['likes'];
    final dislikes = json['dislikes'];
    if (dislikes is! num || (dislikes == 0 && (likes is! num || likes == 0))) return const [];

    return [
      if (likes is num)
        TrackBadge(
          id: 'likes',
          label: _compact(likes.toInt()),
          icon: Icons.thumb_up_alt_rounded,
          tooltip: 'Likes',
        ),
      TrackBadge(
        id: 'dislikes',
        label: _compact(dislikes.toInt()),
        icon: Icons.thumb_down_alt_rounded,
        tooltip: 'Estimated dislikes (Return YouTube Dislike)',
      ),
    ];
  }

  static String _compact(int n) {
    String trim(double v) => v.toStringAsFixed(1).replaceFirst(RegExp(r'\.0$'), '');
    if (n >= 1000000000) return '${trim(n / 1000000000)}B';
    if (n >= 1000000) return '${trim(n / 1000000)}M';
    if (n >= 1000) return '${trim(n / 1000)}K';
    return '$n';
  }
}
