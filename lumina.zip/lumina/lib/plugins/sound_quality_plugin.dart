import 'package:flutter/material.dart' show Icons;

import '../core/models/audio_stream.dart';
import '../core/models/track.dart';
import '../core/plugin/plugin.dart';

/// Shows the real codec and bitrate of the stream you're hearing.
///
/// The label comes straight from [AudioStream.qualityLabel], which only says
/// "Lossless" for codecs that are lossless (FLAC, ALAC, PCM). YouTube Music
/// never serves those, so today you'll see "Opus 160 kbps" or similar. A future
/// Subsonic/local-FLAC source plugin will light up the Lossless badge for real.
class SoundQualityPlugin extends LuminaPlugin implements BadgeProvider {
  @override
  String get id => 'sound-quality';

  @override
  String get name => 'Sound quality';

  @override
  String get description => 'Shows the actual codec and bitrate of the current stream.';

  @override
  Future<List<TrackBadge>> badgesFor(Track track, AudioStream? stream) async {
    if (stream == null) return const [];
    return [
      TrackBadge(
        id: 'quality',
        label: stream.qualityLabel,
        icon: Icons.graphic_eq_rounded,
        tooltip: 'Streamed via ${stream.source}',
      ),
    ];
  }
}
