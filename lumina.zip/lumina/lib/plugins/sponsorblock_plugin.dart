import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

import '../core/models/track.dart';
import '../core/plugin/plugin.dart';

/// Skips sponsors, intros and non-music sections using SponsorBlock's
/// crowd-sourced timestamps.
///
/// Privacy: only the first 4 hex characters of the SHA-256 of the video id are
/// sent, never the id itself. SponsorBlock data is licensed CC BY-NC-SA 4.0
/// (attribution, non-commercial): https://sponsor.ajay.app/
class SponsorBlockPlugin extends LuminaPlugin implements SegmentProvider {
  SponsorBlockPlugin({
    this.categories = defaultCategories,
    this.server = 'sponsor.ajay.app',
  });

  static const defaultCategories = ['sponsor', 'selfpromo', 'intro', 'outro', 'music_offtopic'];

  static const _labels = {
    'sponsor': 'sponsor',
    'selfpromo': 'self-promotion',
    'intro': 'intro',
    'outro': 'outro',
    'interaction': 'reminder',
    'music_offtopic': 'non-music section',
  };

  final List<String> categories;
  final String server;

  late http.Client _client;

  @override
  String get id => 'sponsorblock';

  @override
  String get name => 'SponsorBlock';

  @override
  String get description => 'Skips sponsors, intros and non-music sections.';

  @override
  Future<void> attach(PluginContext context) async {
    _client = context.client;
  }

  @override
  Future<List<SkipSegment>> segmentsFor(Track track) async {
    final prefix = sha256.convert(utf8.encode(track.id)).toString().substring(0, 4);
    final uri = Uri.https(server, '/api/skipSegments/$prefix', {
      'categories': jsonEncode(categories),
      'actionTypes': jsonEncode(['skip']),
    });

    final response = await _client.get(uri, headers: {'Accept': 'application/json'});
    if (response.statusCode == 404) return const []; // nothing submitted for this prefix
    if (response.statusCode != 200) {
      throw http.ClientException('SponsorBlock returned HTTP ${response.statusCode}', uri);
    }

    final videos = (jsonDecode(response.body) as List).cast<Map<String, dynamic>>();
    return [
      for (final video in videos.where((v) => v['videoID'] == track.id))
        for (final segment in (video['segments'] as List).cast<Map<String, dynamic>>())
          _toSegment(segment),
    ];
  }

  SkipSegment _toSegment(Map<String, dynamic> json) {
    final times = (json['segment'] as List).cast<num>();
    final category = json['category'] as String;
    return SkipSegment(
      id: json['UUID'] as String,
      category: category,
      label: _labels[category] ?? category,
      start: _seconds(times[0]),
      end: _seconds(times[1]),
      source: id,
    );
  }

  static Duration _seconds(num s) => Duration(milliseconds: (s * 1000).round());
}
