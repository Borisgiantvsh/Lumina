import 'dart:convert';

import 'package:http/http.dart' as http;

class InnertubeException implements Exception {
  InnertubeException(this.statusCode, this.message);

  final int statusCode;
  final String message;

  @override
  String toString() => 'InnertubeException($statusCode): $message';
}

/// Minimal client for YouTube Music's internal "Innertube" API (WEB_REMIX).
/// Anonymous only; cookie auth for Premium and the personal library is on the
/// roadmap. The response shapes here are undocumented and change without
/// notice, so parsing lives in ytmusic_api.dart and is deliberately defensive.
class InnertubeClient {
  InnertubeClient({http.Client? httpClient, this.language = 'en', this.region = 'US'})
      : _http = httpClient ?? http.Client();

  final http.Client _http;
  final String language;
  final String region;

  static const _origin = 'https://music.youtube.com';
  static const _userAgent =
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0';

  Future<Map<String, dynamic>> post(String endpoint, Map<String, Object?> body) async {
    final uri = Uri.https('music.youtube.com', '/youtubei/v1/$endpoint', {'prettyPrint': 'false'});
    final response = await _http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'Accept-Language': '$language-$region,$language;q=0.8',
        'User-Agent': _userAgent,
        'Origin': _origin,
        'Referer': '$_origin/',
        'X-Goog-AuthUser': '0',
      },
      body: jsonEncode({...body, 'context': _context()}),
    );
    if (response.statusCode != 200) {
      throw InnertubeException(response.statusCode, 'POST /$endpoint failed');
    }
    return jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
  }

  /// WEB_REMIX expects a recent client version; ytmusicapi sends yesterday's date.
  Map<String, Object?> _context() {
    final d = DateTime.now().toUtc().subtract(const Duration(days: 1));
    final ymd = '${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}';
    return {
      'client': {
        'clientName': 'WEB_REMIX',
        'clientVersion': '1.$ymd.01.00',
        'hl': language,
        'gl': region,
      },
      'user': <String, Object?>{},
    };
  }

  void close() => _http.close();
}
