import '../../core/models/audio_stream.dart';

class ResolveException implements Exception {
  ResolveException(this.message, [this.causes = const []]);

  final String message;
  final List<String> causes;

  @override
  String toString() => causes.isEmpty ? message : '$message (${causes.join('; ')})';
}

/// Turns a YouTube video id into a directly playable audio stream.
///
/// This is the part of the app that breaks when YouTube changes its internals,
/// so it sits behind an interface: swap, stack or hot-fix implementations
/// without touching the player.
abstract class StreamResolver {
  String get name;

  Future<AudioStream> resolve(String videoId);

  /// Forget anything cached for [videoId] (call after a 403).
  void invalidate(String videoId) {}
}

/// Memoises results until the signed URL is about to expire and collapses
/// concurrent requests for the same id into one.
class CachingResolver extends StreamResolver {
  CachingResolver(this._inner, {this.maxEntries = 200});

  final StreamResolver _inner;
  final int maxEntries;
  final _cache = <String, AudioStream>{};
  final _inflight = <String, Future<AudioStream>>{};

  @override
  String get name => 'cache(${_inner.name})';

  @override
  Future<AudioStream> resolve(String videoId) {
    final hit = _cache[videoId];
    if (hit != null && hit.isFresh()) return Future.value(hit);

    return _inflight[videoId] ??= _inner.resolve(videoId).then((stream) {
      _cache[videoId] = stream;
      if (_cache.length > maxEntries) _cache.remove(_cache.keys.first);
      return stream;
    }).whenComplete(() => _inflight.remove(videoId));
  }

  @override
  void invalidate(String videoId) {
    _cache.remove(videoId);
    _inner.invalidate(videoId);
  }
}

/// Tries each resolver in order and returns the first success.
class FallbackResolver extends StreamResolver {
  FallbackResolver(this.resolvers, {this.timeout = const Duration(seconds: 20)})
      : assert(resolvers.isNotEmpty, 'Provide at least one resolver');

  final List<StreamResolver> resolvers;
  final Duration timeout;

  @override
  String get name => resolvers.map((r) => r.name).join(' > ');

  @override
  Future<AudioStream> resolve(String videoId) async {
    final failures = <String>[];
    for (final resolver in resolvers) {
      try {
        return await resolver.resolve(videoId).timeout(timeout);
      } catch (error) {
        failures.add('${resolver.name}: $error');
      }
    }
    throw ResolveException('Couldn\u2019t resolve audio for $videoId', failures);
  }

  @override
  void invalidate(String videoId) {
    for (final resolver in resolvers) {
      resolver.invalidate(videoId);
    }
  }
}
