import 'package:youtube_explode_dart/youtube_explode_dart.dart' as yte;

import '../../core/models/audio_stream.dart';
import 'stream_resolver.dart';

/// Dart-only resolver, works on every platform and is maintained upstream
/// (client changes, signature handling), so you don't have to.
///
/// Tuning, all optional:
///  * [clients]: force specific Innertube clients, e.g.
///    `[yte.YoutubeApiClient.androidVr]`.
///  * [client]: pass a pre-configured `YoutubeExplode`, e.g. one with the Deno
///    JS solver enabled (see the package README).
///  * [preferAac]: set on Apple platforms, where AVPlayer can't play Opus/WebM.
class YoutubeExplodeResolver extends StreamResolver {
  YoutubeExplodeResolver({
    yte.YoutubeExplode? client,
    this.clients,
    this.preferAac = false,
  }) : _yt = client ?? yte.YoutubeExplode();

  final yte.YoutubeExplode _yt;
  final List<yte.YoutubeApiClient>? clients;
  final bool preferAac;

  @override
  String get name => 'youtube_explode';

  @override
  Future<AudioStream> resolve(String videoId) async {
    final manifest = await _yt.videos.streams.getManifest(videoId, ytClients: clients);

    var candidates = manifest.audioOnly.toList();
    if (preferAac) {
      final aac = candidates.where((s) => s.audioCodec.contains('mp4a')).toList();
      if (aac.isNotEmpty) candidates = aac;
    }
    if (candidates.isEmpty) {
      throw ResolveException('No audio-only streams for $videoId');
    }

    // Highest bitrate wins. Anonymous requests top out around 160 kbps Opus;
    // 256 kbps AAC needs a Premium-authenticated resolver (see README roadmap).
    candidates.sort((a, b) => b.bitrate.bitsPerSecond.compareTo(a.bitrate.bitsPerSecond));
    final best = candidates.first;

    return AudioStream(
      url: best.url,
      codec: AudioCodec.parse(best.audioCodec),
      bitrateKbps: (best.bitrate.bitsPerSecond / 1000).round(),
      container: best.container.name,
      expiresAt: AudioStream.expiryFromUrl(best.url),
      source: name,
    );
  }

  void close() => _yt.close();
}
