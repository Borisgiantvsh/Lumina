import 'dart:convert';
import 'dart:io';

import '../../core/models/audio_stream.dart';
import 'stream_resolver.dart';

/// Desktop safety net: asks a locally installed `yt-dlp` for the best audio
/// stream. yt-dlp is updated within hours of YouTube changes, so this keeps
/// desktop playback alive while the Dart extractor catches up.
class YtDlpResolver extends StreamResolver {
  YtDlpResolver({this.executable = 'yt-dlp', this.extraArgs = const []});

  final String executable;
  final List<String> extraArgs;

  @override
  String get name => 'yt-dlp';

  @override
  Future<AudioStream> resolve(String videoId) async {
    final ProcessResult result;
    try {
      result = await Process.run(executable, [
        '-f',
        'bestaudio/best',
        '--no-playlist',
        '--no-warnings',
        '--dump-single-json',
        ...extraArgs,
        'https://music.youtube.com/watch?v=$videoId',
      ]);
    } on ProcessException catch (e) {
      throw ResolveException('yt-dlp isn\u2019t installed or couldn\u2019t start: ${e.message}');
    }

    if (result.exitCode != 0) {
      throw ResolveException('yt-dlp exited with ${result.exitCode}: ${'${result.stderr}'.trim()}');
    }

    final json = jsonDecode('${result.stdout}') as Map<String, dynamic>;
    final rawUrl = json['url'] as String?;
    if (rawUrl == null) throw ResolveException('yt-dlp returned no stream URL');
    final url = Uri.parse(rawUrl);

    final headers = <String, String>{};
    final rawHeaders = json['http_headers'];
    if (rawHeaders is Map) {
      rawHeaders.forEach((key, value) {
        final k = '$key';
        if (k.toLowerCase() != 'accept-encoding') headers[k] = '$value';
      });
    }

    return AudioStream(
      url: url,
      codec: AudioCodec.parse(json['acodec'] as String?),
      bitrateKbps: (json['abr'] as num?)?.round() ?? 0,
      sampleRateHz: (json['asr'] as num?)?.round(),
      container: json['ext'] as String?,
      headers: headers,
      expiresAt: AudioStream.expiryFromUrl(url),
      source: name,
    );
  }
}
