import '../../core/models/track.dart';
import 'innertube_client.dart';

/// Null-safe walk through decoded JSON: `dig<String>(json, ['a', 0, 'b'])`.
/// Returns null at the first missing key, wrong type or out-of-range index.
T? dig<T>(dynamic root, List<Object> path) {
  dynamic current = root;
  for (final key in path) {
    if (key is int) {
      if (current is List && key >= 0 && key < current.length) {
        current = current[key];
      } else {
        return null;
      }
    } else if (key is String) {
      if (current is Map) {
        current = current[key];
      } else {
        return null;
      }
    } else {
      return null;
    }
    if (current == null) return null;
  }
  return current is T ? current : null;
}

class YtMusicApi {
  YtMusicApi(this._client);

  final InnertubeClient _client;

  /// ytmusicapi's search filter for "Songs".
  static const _songsFilter = 'EgWKAQIIAWoMEA4QChADEAQQCRAF';

  Future<List<Track>> searchSongs(String query, {int limit = 20}) async {
    final q = query.trim();
    if (q.isEmpty) return const [];

    var tracks = parseSongResults(
      await _client.post('search', {'query': q, 'params': _songsFilter}),
    );
    if (tracks.isEmpty) {
      // The filter token can go stale; unfiltered results still parse.
      tracks = parseSongResults(await _client.post('search', {'query': q}));
    }
    return tracks.take(limit).toList();
  }
}

/// Exposed for tests: drop a captured response into test/fixtures and assert.
List<Track> parseSongResults(Map<String, dynamic> json) {
  final sections = dig<List>(json, [
        'contents',
        'tabbedSearchResultsRenderer',
        'tabs',
        0,
        'tabRenderer',
        'content',
        'sectionListRenderer',
        'contents',
      ]) ??
      const [];

  final tracks = <Track>[];
  for (final section in sections) {
    final items = dig<List>(section, ['musicShelfRenderer', 'contents']) ?? const [];
    for (final item in items) {
      final track = _parseListItem(dig<Map>(item, ['musicResponsiveListItemRenderer']));
      if (track != null) tracks.add(track);
    }
  }
  return tracks;
}

Track? _parseListItem(Map? item) {
  if (item == null) return null;

  final videoId = dig<String>(item, ['playlistItemData', 'videoId']) ??
      dig<String>(item, [
        'overlay',
        'musicItemThumbnailOverlayRenderer',
        'content',
        'musicPlayButtonRenderer',
        'playNavigationEndpoint',
        'watchEndpoint',
        'videoId',
      ]);
  if (videoId == null) return null; // albums, artists and playlists have no videoId

  final columns = dig<List>(item, ['flexColumns']) ?? const [];
  List runsOf(int index) =>
      dig<List>(index < columns.length ? columns[index] : null, [
        'musicResponsiveListItemFlexColumnRenderer',
        'text',
        'runs',
      ]) ??
      const [];

  final title = dig<String>(runsOf(0).isEmpty ? null : runsOf(0).first, ['text']);
  if (title == null || title.isEmpty) return null;

  // Subtitle runs look like: Artist " • " Album " • " 3:45, optionally with a
  // leading type label ("Song", "Video") in unfiltered results.
  final segments = <String>[];
  var buffer = StringBuffer();
  for (final run in runsOf(1)) {
    final text = dig<String>(run, ['text']) ?? '';
    if (text.trim() == '\u2022') {
      segments.add(buffer.toString().trim());
      buffer = StringBuffer();
    } else {
      buffer.write(text);
    }
  }
  segments.add(buffer.toString().trim());
  segments.removeWhere((s) => s.isEmpty);

  if (segments.isNotEmpty && const {'Song', 'Video', 'Single', 'EP'}.contains(segments.first)) {
    segments.removeAt(0);
  }
  Duration? duration;
  if (segments.isNotEmpty && _clock.hasMatch(segments.last)) {
    duration = _parseClock(segments.removeLast());
  }

  final thumbnails = dig<List>(item, [
        'thumbnail',
        'musicThumbnailRenderer',
        'thumbnail',
        'thumbnails',
      ]) ??
      const [];

  return Track(
    id: videoId,
    title: title,
    artist: segments.isNotEmpty ? segments.first : 'Unknown artist',
    album: segments.length > 1 ? segments[1] : null,
    duration: duration,
    artworkUrl: thumbnails.isEmpty ? null : dig<String>(thumbnails.last, ['url']),
  );
}

final _clock = RegExp(r'^\d+(:\d{2}){1,2}$');

Duration _parseClock(String text) {
  final parts = text.split(':').map(int.parse).toList();
  return switch (parts.length) {
    3 => Duration(hours: parts[0], minutes: parts[1], seconds: parts[2]),
    _ => Duration(minutes: parts[0], seconds: parts[1]),
  };
}
