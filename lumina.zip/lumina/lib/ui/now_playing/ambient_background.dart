import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Slow-drifting colour blobs derived from the artwork, in the spirit of Apple
/// Music's Now Playing backdrop. Colours cross-fade when the track changes and
/// the motion stops when the system asks for reduced animation.
class AmbientBackground extends StatefulWidget {
  const AmbientBackground({super.key, required this.colors});

  final List<Color> colors;

  static const fallback = <Color>[
    Color(0xFF4A3B7C),
    Color(0xFF244B7A),
    Color(0xFF7A3B5C),
    Color(0xFF2B2B38),
  ];

  @override
  State<AmbientBackground> createState() => _AmbientBackgroundState();
}

class _AmbientBackgroundState extends State<AmbientBackground> with SingleTickerProviderStateMixin {
  // Whole-number frequencies keep the loop seamless when the controller wraps.
  static const _kx = [1, 2, 1, 2];
  static const _ky = [2, 1, 1, 3];
  static const _phase = [0.0, 1.9, 3.6, 5.1];

  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 40),
  );

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.disableAnimationsOf(context)) {
      _controller.stop();
    } else if (!_controller.isAnimating) {
      _controller.repeat();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          final t = _controller.value * math.pi * 2;
          return LayoutBuilder(
            builder: (context, box) {
              final longest = box.biggest.longestSide;
              return Stack(
                children: [
                  const Positioned.fill(child: ColoredBox(color: Color(0xFF0B0B10))),
                  for (var i = 0; i < widget.colors.length && i < 4; i++)
                    Positioned(
                      left: box.maxWidth * (0.5 + 0.45 * math.cos(t * _kx[i] + _phase[i])) -
                          longest * (0.55 + 0.1 * (i % 2)),
                      top: box.maxHeight * (0.5 + 0.45 * math.sin(t * _ky[i] + _phase[i])) -
                          longest * (0.55 + 0.1 * (i % 2)),
                      width: longest * 2 * (0.55 + 0.1 * (i % 2)),
                      height: longest * 2 * (0.55 + 0.1 * (i % 2)),
                      child: _Blob(color: widget.colors[i]),
                    ),
                  // Keeps white text legible over bright artwork.
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withValues(alpha: 0.10),
                            Colors.black.withValues(alpha: 0.45),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _Blob extends StatelessWidget {
  const _Blob({required this.color});

  final Color color;

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<Color?>(
      tween: ColorTween(end: color),
      duration: const Duration(milliseconds: 1200),
      builder: (context, value, _) {
        final c = value ?? color;
        return DecoratedBox(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: [c.withValues(alpha: 0.9), c.withValues(alpha: 0)],
            ),
          ),
        );
      },
    );
  }
}
