import 'package:flutter/material.dart';

import '../../core/models/lyrics.dart';
import '../../core/playback/player_controller.dart';

/// Big, bold lyrics that follow playback. Tap a line to jump to it. Scrolling
/// by hand pauses auto-follow for a few seconds.
class LyricsView extends StatefulWidget {
  const LyricsView({super.key, required this.controller, this.fontSize = 30});

  final PlayerController controller;
  final double fontSize;

  @override
  State<LyricsView> createState() => _LyricsViewState();
}

class _LyricsViewState extends State<LyricsView> {
  final _scroll = ScrollController();
  List<GlobalKey> _keys = const [];
  Lyrics? _lyrics;
  int _active = -1;
  DateTime _manualUntil = DateTime.fromMillisecondsSinceEpoch(0);

  PlayerController get _c => widget.controller;

  @override
  void initState() {
    super.initState();
    _c.position.addListener(_onTick);
  }

  @override
  void dispose() {
    _c.position.removeListener(_onTick);
    _scroll.dispose();
    super.dispose();
  }

  void _onTick() {
    final lyrics = _lyrics;
    if (!mounted || lyrics == null || !lyrics.synced) return;
    final index = lyrics.indexAt(_c.position.value);
    if (index == _active) return;
    setState(() => _active = index);
    _follow();
  }

  void _follow() {
    if (_active < 0 || _active >= _keys.length) return;
    if (DateTime.now().isBefore(_manualUntil)) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_active < 0 || _active >= _keys.length) return;
      final context = _keys[_active].currentContext;
      if (context == null || !context.mounted) return;
      Scrollable.ensureVisible(
        context,
        alignment: 0.32,
        duration: const Duration(milliseconds: 520),
        curve: Curves.easeOutCubic,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _c,
      builder: (context, _) {
        final lyrics = _c.lyrics;
        if (!identical(lyrics, _lyrics)) {
          _lyrics = lyrics;
          _keys = List.generate(lyrics?.lines.length ?? 0, (_) => GlobalKey());
          _active = lyrics != null && lyrics.synced ? lyrics.indexAt(_c.position.value) : -1;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (_scroll.hasClients) _scroll.jumpTo(0);
            _follow();
          });
        }
        return _body(lyrics);
      },
    );
  }

  Widget _body(Lyrics? lyrics) {
    if (lyrics == null) {
      return Center(
        child: _c.lyricsLoading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white54),
              )
            : const Text(
                'No lyrics for this track',
                style: TextStyle(color: Colors.white54, fontSize: 18, fontWeight: FontWeight.w600),
              ),
      );
    }

    return LayoutBuilder(
      builder: (context, box) {
        final padding = box.maxHeight * 0.38;
        return NotificationListener<ScrollStartNotification>(
          onNotification: (n) {
            if (n.dragDetails != null) {
              _manualUntil = DateTime.now().add(const Duration(seconds: 4));
            }
            return false;
          },
          child: ShaderMask(
            blendMode: BlendMode.dstIn,
            shaderCallback: (rect) => const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.transparent, Colors.black, Colors.black, Colors.transparent],
              stops: [0, 0.08, 0.88, 1],
            ).createShader(rect),
            child: SingleChildScrollView(
              controller: _scroll,
              padding: EdgeInsets.only(top: padding * 0.6, bottom: padding, right: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (var i = 0; i < lyrics.lines.length; i++) _line(i, lyrics),
                  if (lyrics.source != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 24),
                      child: Text(
                        'Lyrics from ${lyrics.source}',
                        style: const TextStyle(color: Colors.white38, fontSize: 12),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _line(int index, Lyrics lyrics) {
    final line = lyrics.lines[index];
    final isActive = lyrics.synced && index == _active;
    final distance = _active < 0 ? index + 1 : (index - _active).abs();
    final opacity = !lyrics.synced
        ? 0.85
        : isActive
            ? 1.0
            : distance == 1
                ? 0.5
                : distance == 2
                    ? 0.38
                    : 0.28;

    return GestureDetector(
      key: index < _keys.length ? _keys[index] : null,
      behavior: HitTestBehavior.opaque,
      onTap: lyrics.synced ? () => _c.seek(line.start) : null,
      child: AnimatedScale(
        scale: isActive || !lyrics.synced ? 1.0 : 0.93,
        alignment: Alignment.centerLeft,
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
        child: AnimatedOpacity(
          opacity: opacity,
          duration: const Duration(milliseconds: 350),
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: widget.fontSize * 0.28),
            child: Text(
              line.text.isEmpty ? '\u266A' : line.text,
              style: TextStyle(
                fontSize: widget.fontSize,
                height: 1.22,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.6,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
