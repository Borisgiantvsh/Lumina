import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/models/track.dart';
import '../../core/playback/player_controller.dart';
import '../../core/plugin/plugin.dart';
import 'ambient_background.dart';
import 'lyrics_view.dart';
import 'scrubber.dart';

/// Slides up from the bottom like Apple Music's player sheet.
Route<void> nowPlayingRoute(PlayerController controller) {
  return PageRouteBuilder<void>(
    transitionDuration: const Duration(milliseconds: 420),
    reverseTransitionDuration: const Duration(milliseconds: 320),
    pageBuilder: (_, __, ___) => NowPlayingScreen(controller: controller),
    transitionsBuilder: (_, animation, __, child) {
      final curved = CurvedAnimation(
        parent: animation,
        curve: Curves.easeOutCubic,
        reverseCurve: Curves.easeInCubic,
      );
      return SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero).animate(curved),
        child: child,
      );
    },
  );
}

class NowPlayingScreen extends StatefulWidget {
  const NowPlayingScreen({super.key, required this.controller});

  final PlayerController controller;

  @override
  State<NowPlayingScreen> createState() => _NowPlayingScreenState();
}

class _NowPlayingScreenState extends State<NowPlayingScreen> {
  PlayerController get _c => widget.controller;

  bool _showLyrics = false;
  List<Color> _colors = AmbientBackground.fallback;
  String? _paletteFor;
  StreamSubscription<String>? _toasts;

  @override
  void initState() {
    super.initState();
    _toasts = _c.toasts.listen(_showToast);
    _c.addListener(_onController);
    _paletteFor = _c.current?.id;
    unawaited(_loadPalette(_c.current));
  }

  @override
  void dispose() {
    _c.removeListener(_onController);
    unawaited(_toasts?.cancel());
    super.dispose();
  }

  void _onController() {
    final track = _c.current;
    if (track?.id == _paletteFor) return;
    _paletteFor = track?.id;
    unawaited(_loadPalette(track));
  }

  Future<void> _loadPalette(Track? track) async {
    final url = track?.artwork(size: 160);
    if (track == null || url == null) return;
    try {
      final scheme = await ColorScheme.fromImageProvider(
        provider: NetworkImage(url),
        brightness: Brightness.dark,
      );
      if (!mounted || _c.current?.id != track.id) return;
      setState(() {
        _colors = [scheme.primary, scheme.tertiary, scheme.primaryContainer, scheme.secondary]
            .map(_vivid)
            .toList();
      });
    } catch (_) {
      // Keep the previous palette if the artwork can't be decoded.
    }
  }

  void _showToast(String message) {
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
          backgroundColor: const Color(0xE6222228),
          margin: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      );
  }

  void _close() => Navigator.of(context).maybePop();

  @override
  Widget build(BuildContext context) {
    return CallbackShortcuts(
      bindings: {
        const SingleActivator(LogicalKeyboardKey.space): _c.togglePlay,
        const SingleActivator(LogicalKeyboardKey.arrowRight): () =>
            _c.seek(_c.position.value + const Duration(seconds: 10)),
        const SingleActivator(LogicalKeyboardKey.arrowLeft): () =>
            _c.seek(_c.position.value - const Duration(seconds: 10)),
        const SingleActivator(LogicalKeyboardKey.escape): _close,
      },
      child: Focus(
        autofocus: true,
        child: Scaffold(
          backgroundColor: Colors.black,
          body: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onVerticalDragEnd: (d) {
              if ((d.primaryVelocity ?? 0) > 800) _close();
            },
            child: Stack(
              children: [
                Positioned.fill(child: AmbientBackground(colors: _colors)),
                SafeArea(
                  child: ListenableBuilder(
                    listenable: _c,
                    builder: (context, _) => LayoutBuilder(
                      builder: (context, box) =>
                          box.maxWidth >= 900 ? _wide(box) : _narrow(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ---- phone / narrow layout -----------------------------------------------

  Widget _narrow() {
    final track = _c.current;
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 6, 28, 18),
      child: Column(
        children: [
          GestureDetector(
            onTap: _close,
            behavior: HitTestBehavior.opaque,
            child: const _Grabber(),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 380),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              child: _showLyrics
                  ? Column(
                      key: const ValueKey('lyrics'),
                      children: [
                        Row(
                          children: [
                            _Artwork(url: track?.artwork(size: 160), size: 56, radius: 8),
                            const SizedBox(width: 14),
                            Expanded(child: _TitleBlock(track: track, titleSize: 18, subtitleSize: 16)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Expanded(child: LyricsView(controller: _c, fontSize: 30)),
                      ],
                    )
                  : KeyedSubtree(
                      key: const ValueKey('art'),
                      child: _ArtworkStage(track: track, playing: _c.isPlaying),
                    ),
            ),
          ),
          if (!_showLyrics) ...[
            const SizedBox(height: 18),
            _TitleBlock(track: track),
          ],
          const SizedBox(height: 14),
          _SeekBar(controller: _c),
          const SizedBox(height: 4),
          _BadgeRow(badges: _c.badges),
          _ErrorLine(message: _c.error),
          const SizedBox(height: 6),
          _Transport(controller: _c),
          const SizedBox(height: 10),
          _Footer(
            controller: _c,
            showLyricsToggle: true,
            lyricsOn: _showLyrics,
            onLyrics: () => setState(() => _showLyrics = !_showLyrics),
          ),
        ],
      ),
    );
  }

  // ---- desktop / wide layout -----------------------------------------------

  Widget _wide(BoxConstraints box) {
    final track = _c.current;
    return Padding(
      padding: const EdgeInsets.fromLTRB(40, 12, 40, 28),
      child: Row(
        children: [
          SizedBox(
            width: math.min(460, box.maxWidth * 0.38),
            child: Column(
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: IconButton(
                    tooltip: 'Close',
                    onPressed: _close,
                    icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white, size: 30),
                  ),
                ),
                Expanded(child: _ArtworkStage(track: track, playing: _c.isPlaying)),
                const SizedBox(height: 22),
                _TitleBlock(track: track),
                const SizedBox(height: 14),
                _SeekBar(controller: _c),
                const SizedBox(height: 4),
                _BadgeRow(badges: _c.badges),
                _ErrorLine(message: _c.error),
                const SizedBox(height: 6),
                _Transport(controller: _c),
                const SizedBox(height: 10),
                _Footer(
                  controller: _c,
                  showLyricsToggle: false,
                  lyricsOn: true,
                  onLyrics: () {},
                ),
              ],
            ),
          ),
          const SizedBox(width: 56),
          Expanded(child: LyricsView(controller: _c, fontSize: 40)),
        ],
      ),
    );
  }
}

/// Pulls vivid, mid-tone colours out of the artwork scheme.
Color _vivid(Color color) {
  final hsl = HSLColor.fromColor(color);
  return hsl
      .withSaturation((hsl.saturation * 1.15).clamp(0.5, 0.95))
      .withLightness(hsl.lightness.clamp(0.30, 0.52))
      .toColor();
}

// ---- pieces -------------------------------------------------------------------

class _Grabber extends StatelessWidget {
  const _Grabber();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 40,
        height: 5,
        margin: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.35),
          borderRadius: BorderRadius.circular(3),
        ),
      ),
    );
  }
}

/// Artwork that shrinks when paused, like Apple Music.
class _ArtworkStage extends StatelessWidget {
  const _ArtworkStage({required this.track, required this.playing});

  final Track? track;
  final bool playing;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        final side = math.min(box.maxWidth, box.maxHeight);
        return Center(
          child: AnimatedScale(
            scale: playing ? 1.0 : 0.86,
            duration: const Duration(milliseconds: 500),
            curve: Curves.easeOutCubic,
            child: _Artwork(url: track?.artwork(size: 800), size: side),
          ),
        );
      },
    );
  }
}

class _Artwork extends StatelessWidget {
  const _Artwork({required this.url, required this.size, this.radius = 14});

  final String? url;
  final double size;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final u = url;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.4),
            blurRadius: size * 0.12,
            offset: Offset(0, size * 0.05),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 350),
          child: u == null
              ? const _ArtPlaceholder(key: ValueKey('none'))
              : Image.network(
                  u,
                  key: ValueKey(u),
                  width: size,
                  height: size,
                  fit: BoxFit.cover,
                  gaplessPlayback: true,
                  errorBuilder: (_, __, ___) => const _ArtPlaceholder(),
                ),
        ),
      ),
    );
  }
}

class _ArtPlaceholder extends StatelessWidget {
  const _ArtPlaceholder({super.key});

  @override
  Widget build(BuildContext context) {
    return const DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF3A3A44), Color(0xFF1C1C22)],
        ),
      ),
      child: Center(child: Icon(Icons.music_note_rounded, color: Colors.white38, size: 64)),
    );
  }
}

class _TitleBlock extends StatelessWidget {
  const _TitleBlock({required this.track, this.titleSize = 24, this.subtitleSize = 20});

  final Track? track;
  final double titleSize;
  final double subtitleSize;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            track?.title ?? 'Nothing playing',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: titleSize,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.4,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            track?.artist ?? '',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: subtitleSize,
              fontWeight: FontWeight.w500,
              color: Colors.white.withValues(alpha: 0.62),
            ),
          ),
        ],
      ),
    );
  }
}

class _SeekBar extends StatelessWidget {
  const _SeekBar({required this.controller});

  final PlayerController controller;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Duration>(
      valueListenable: controller.duration,
      builder: (context, total, _) => ValueListenableBuilder<Duration>(
        valueListenable: controller.position,
        builder: (context, position, _) => Scrubber(
          position: position,
          duration: total,
          onSeek: controller.seek,
        ),
      ),
    );
  }
}

class _BadgeRow extends StatelessWidget {
  const _BadgeRow({required this.badges});

  final List<TrackBadge> badges;

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minHeight: 28),
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: Wrap(
          key: ValueKey(badges.map((b) => '${b.id}:${b.label}').join('|')),
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 6,
          runSpacing: 6,
          children: [for (final badge in badges) _BadgePill(badge: badge)],
        ),
      ),
    );
  }
}

class _BadgePill extends StatelessWidget {
  const _BadgePill({required this.badge});

  final TrackBadge badge;

  @override
  Widget build(BuildContext context) {
    final pill = DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (badge.icon != null) ...[
              Icon(badge.icon, size: 12, color: Colors.white.withValues(alpha: 0.8)),
              const SizedBox(width: 4),
            ],
            Text(
              badge.label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.2,
                color: Colors.white.withValues(alpha: 0.82),
              ),
            ),
          ],
        ),
      ),
    );
    final tooltip = badge.tooltip;
    return tooltip == null ? pill : Tooltip(message: tooltip, child: pill);
  }
}

class _ErrorLine extends StatelessWidget {
  const _ErrorLine({required this.message});

  final String? message;

  @override
  Widget build(BuildContext context) {
    final text = message;
    if (text == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Text(
        text,
        textAlign: TextAlign.center,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Color(0xFFFF8A95), fontSize: 13, fontWeight: FontWeight.w600),
      ),
    );
  }
}

class _Transport extends StatelessWidget {
  const _Transport({required this.controller});

  final PlayerController controller;

  @override
  Widget build(BuildContext context) {
    final playing = controller.isPlaying;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _Pressable(
          label: 'Previous',
          onTap: controller.previous,
          child: const Icon(Icons.fast_rewind_rounded, size: 52, color: Colors.white),
        ),
        _Pressable(
          label: playing ? 'Pause' : 'Play',
          onTap: controller.togglePlay,
          child: SizedBox(
            width: 84,
            height: 84,
            child: Center(
              child: controller.isBusy
                  ? const SizedBox(
                      width: 34,
                      height: 34,
                      child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white),
                    )
                  : AnimatedSwitcher(
                      duration: const Duration(milliseconds: 180),
                      transitionBuilder: (child, animation) => ScaleTransition(
                        scale: animation,
                        child: FadeTransition(opacity: animation, child: child),
                      ),
                      child: Icon(
                        playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        key: ValueKey(playing),
                        size: 84,
                        color: Colors.white,
                      ),
                    ),
            ),
          ),
        ),
        _Pressable(
          label: 'Next',
          onTap: controller.next,
          child: const Icon(Icons.fast_forward_rounded, size: 52, color: Colors.white),
        ),
      ],
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer({
    required this.controller,
    required this.showLyricsToggle,
    required this.lyricsOn,
    required this.onLyrics,
  });

  final PlayerController controller;
  final bool showLyricsToggle;
  final bool lyricsOn;
  final VoidCallback onLyrics;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _ToggleIcon(
          label: 'Shuffle',
          icon: Icons.shuffle_rounded,
          active: controller.shuffle,
          onTap: controller.toggleShuffle,
        ),
        if (showLyricsToggle)
          _ToggleIcon(
            label: 'Lyrics',
            icon: Icons.format_quote_rounded,
            active: lyricsOn,
            onTap: onLyrics,
          ),
        _ToggleIcon(
          label: 'Repeat',
          icon: controller.repeat == RepeatMode.one ? Icons.repeat_one_rounded : Icons.repeat_rounded,
          active: controller.repeat != RepeatMode.off,
          onTap: controller.cycleRepeat,
        ),
      ],
    );
  }
}

class _ToggleIcon extends StatelessWidget {
  const _ToggleIcon({
    required this.label,
    required this.icon,
    required this.active,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return _Pressable(
      label: label,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 48,
        height: 38,
        decoration: BoxDecoration(
          color: active ? Colors.white.withValues(alpha: 0.22) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(
          icon,
          size: 22,
          color: active ? Colors.white : Colors.white.withValues(alpha: 0.65),
        ),
      ),
    );
  }
}

/// Press-and-shrink feedback used by every control.
class _Pressable extends StatefulWidget {
  const _Pressable({required this.child, required this.onTap, required this.label});

  final Widget child;
  final VoidCallback onTap;
  final String label;

  @override
  State<_Pressable> createState() => _PressableState();
}

class _PressableState extends State<_Pressable> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: widget.label,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) => setState(() => _down = false),
        onTapCancel: () => setState(() => _down = false),
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: _down ? 0.88 : 1.0,
          duration: const Duration(milliseconds: 120),
          child: widget.child,
        ),
      ),
    );
  }
}
