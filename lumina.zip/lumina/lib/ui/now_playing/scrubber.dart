import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

String formatDuration(Duration d) {
  if (d.isNegative) d = Duration.zero;
  final h = d.inHours;
  final m = d.inMinutes.remainder(60);
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return h > 0 ? '$h:${m.toString().padLeft(2, '0')}:$s' : '$m:$s';
}

/// A thin progress bar that thickens while you drag, with elapsed and
/// remaining time underneath.
class Scrubber extends StatefulWidget {
  const Scrubber({
    super.key,
    required this.position,
    required this.duration,
    required this.onSeek,
  });

  final Duration position;
  final Duration duration;
  final ValueChanged<Duration> onSeek;

  @override
  State<Scrubber> createState() => _ScrubberState();
}

class _ScrubberState extends State<Scrubber> {
  double? _value; // fraction shown while dragging and briefly after release
  bool _dragging = false;
  Timer? _settle;

  @override
  void dispose() {
    _settle?.cancel();
    super.dispose();
  }

  double get _fraction {
    final total = widget.duration.inMilliseconds;
    if (total <= 0) return 0;
    return (widget.position.inMilliseconds / total).clamp(0.0, 1.0);
  }

  Duration _at(double fraction) =>
      Duration(milliseconds: (widget.duration.inMilliseconds * fraction).round());

  void _begin(double fraction) {
    _settle?.cancel();
    setState(() {
      _dragging = true;
      _value = fraction;
    });
  }

  void _commit(double fraction) {
    setState(() {
      _dragging = false;
      _value = fraction;
    });
    widget.onSeek(_at(fraction));
    // Hold the thumb at the target until the player catches up.
    _settle?.cancel();
    _settle = Timer(const Duration(milliseconds: 500), () {
      if (mounted) setState(() => _value = null);
    });
  }

  @override
  Widget build(BuildContext context) {
    final fraction = _value ?? _fraction;
    final shown = _value != null ? _at(_value!) : widget.position;
    final remaining = widget.duration - shown;

    const labelStyle = TextStyle(
      fontSize: 12,
      fontWeight: FontWeight.w600,
      color: Color(0x8CFFFFFF),
      fontFeatures: [FontFeature.tabularFigures()],
    );

    return Semantics(
      label: 'Seek',
      value: '${formatDuration(shown)} of ${formatDuration(widget.duration)}',
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          LayoutBuilder(
            builder: (context, box) {
              double at(Offset p) => (p.dx / box.maxWidth).clamp(0.0, 1.0);
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTapUp: (d) => _commit(at(d.localPosition)),
                onHorizontalDragStart: (d) => _begin(at(d.localPosition)),
                onHorizontalDragUpdate: (d) => setState(() => _value = at(d.localPosition)),
                onHorizontalDragEnd: (_) {
                  final v = _value;
                  if (v != null) _commit(v);
                },
                onHorizontalDragCancel: () => setState(() {
                  _dragging = false;
                  _value = null;
                }),
                child: SizedBox(
                  height: 28,
                  child: Center(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 160),
                      curve: Curves.easeOut,
                      height: _dragging ? 12 : 6,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.22),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: FractionallySizedBox(
                          widthFactor: fraction,
                          heightFactor: 1,
                          child: const ColoredBox(color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(formatDuration(shown), style: labelStyle),
              Text('-${formatDuration(remaining)}', style: labelStyle),
            ],
          ),
        ],
      ),
    );
  }
}
