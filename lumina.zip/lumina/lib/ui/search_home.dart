import 'dart:async';
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

import '../core/models/track.dart';
import '../core/playback/player_controller.dart';
import '../sources/ytmusic/ytmusic_api.dart';
import 'now_playing/now_playing_screen.dart';
import 'now_playing/scrubber.dart' show formatDuration;
import 'widgets/mini_player.dart';

class SearchHome extends StatefulWidget {
  const SearchHome({super.key, required this.controller, required this.api});

  final PlayerController controller;
  final YtMusicApi api;

  @override
  State<SearchHome> createState() => _SearchHomeState();
}

class _SearchHomeState extends State<SearchHome> {
  final _field = TextEditingController();
  Timer? _debounce;
  List<Track> _results = const [];
  bool _searching = false;
  String? _error;
  int _searchToken = 0;

  @override
  void dispose() {
    _debounce?.cancel();
    _field.dispose();
    super.dispose();
  }

  void _onChanged(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () => _search(value));
  }

  Future<void> _search(String query) async {
    final token = ++_searchToken;
    if (query.trim().isEmpty) {
      setState(() {
        _results = const [];
        _searching = false;
        _error = null;
      });
      return;
    }
    setState(() {
      _searching = true;
      _error = null;
    });
    try {
      final results = await widget.api.searchSongs(query);
      if (!mounted || token != _searchToken) return;
      setState(() {
        _results = results;
        _searching = false;
      });
    } catch (_) {
      if (!mounted || token != _searchToken) return;
      setState(() {
        _searching = false;
        _error = 'Couldn\u2019t reach YouTube Music. Check your connection and try again.';
      });
    }
  }

  void _openNowPlaying() => Navigator.of(context).push(nowPlayingRoute(widget.controller));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Search',
                    style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -0.8),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _field,
                    onChanged: _onChanged,
                    onSubmitted: _search,
                    textInputAction: TextInputAction.search,
                    decoration: const InputDecoration(
                      hintText: 'Songs, artists, lyrics',
                      prefixIcon: Icon(Icons.search_rounded, color: Colors.white54),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: _body()),
            SafeArea(
              top: false,
              child: MiniPlayer(controller: widget.controller, onOpen: _openNowPlaying),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    if (_searching && _results.isEmpty) {
      return const Center(child: CircularProgressIndicator(strokeWidth: 2.5));
    }
    if (_error != null) return _Message(_error!);
    if (_results.isEmpty) return const _Message('Search for a song to start listening.');

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 12),
      itemCount: _results.length,
      itemBuilder: (context, i) => _ResultTile(
        track: _results[i],
        onTap: () => widget.controller.playQueue(_results, startIndex: i),
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  const _ResultTile({required this.track, required this.onTap});

  final Track track;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final art = track.artwork(size: 128);
    final duration = track.duration;
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: SizedBox(
          width: 52,
          height: 52,
          child: art == null
              ? const ColoredBox(color: Color(0xFF2C2C34))
              : Image.network(art, fit: BoxFit.cover),
        ),
      ),
      title: Text(
        track.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
      subtitle: Text(
        track.artist,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(color: Colors.white.withValues(alpha: 0.6)),
      ),
      trailing: duration == null
          ? null
          : Text(
              formatDuration(duration),
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.5),
                fontSize: 13,
                fontFeatures: const [FontFeature.tabularFigures()],
              ),
            ),
    );
  }
}

class _Message extends StatelessWidget {
  const _Message(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white54, fontSize: 16),
        ),
      ),
    );
  }
}
