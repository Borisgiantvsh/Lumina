import 'package:flutter/material.dart';

/// Apple Music's red, used sparingly.
const luminaAccent = Color(0xFFFA2D48);

ThemeData buildLuminaTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: luminaAccent,
    brightness: Brightness.dark,
  ).copyWith(surface: Colors.black);

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: Colors.black,
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
    dividerColor: Colors.white12,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFF1C1C1E),
      hintStyle: const TextStyle(color: Colors.white54),
      contentPadding: const EdgeInsets.symmetric(vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
    ),
  );
}
