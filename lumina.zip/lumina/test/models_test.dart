import 'package:flutter_test/flutter_test.dart';
import 'package:lumina/core/models/audio_stream.dart';
import 'package:lumina/core/models/lyrics.dart';

void main() {
  group('Lyrics.fromLrc', () {
    test('parses timestamps and multi-tag lines, ignores metadata tags', () {
      final lyrics = Lyrics.fromLrc('[ar:Someone]\n[00:01.50]Hello\n[00:03.00][01:00.25]Again\n');
      expect(lyrics.synced, isTrue);
      expect(lyrics.lines.map((l) => l.text), ['Hello', 'Again', 'Again']);
      expect(lyrics.lines.first.start, const Duration(seconds: 1, milliseconds: 500));
      expect(lyrics.lines.last.start, const Duration(minutes: 1, milliseconds: 250));
    });

    test('indexAt returns the line being sung', () {
      final lyrics = Lyrics.fromLrc('[00:05.00]a\n[00:10.00]b');
      expect(lyrics.indexAt(const Duration(seconds: 1)), -1);
      expect(lyrics.indexAt(const Duration(seconds: 5)), 0);
      expect(lyrics.indexAt(const Duration(seconds: 12)), 1);
    });
  });

  group('AudioStream quality label', () {
    AudioStream stream(AudioCodec codec, int kbps) => AudioStream(
          url: Uri.parse('https://example.com/a'),
          codec: codec,
          bitrateKbps: kbps,
          expiresAt: DateTime.now().add(const Duration(hours: 1)),
        );

    test('lossy codecs are never labelled lossless', () {
      for (final codec in [AudioCodec.opus, AudioCodec.aac, AudioCodec.mp3, AudioCodec.vorbis]) {
        expect(stream(codec, 256).isLossless, isFalse);
        expect(stream(codec, 256).qualityLabel.toLowerCase(), isNot(contains('lossless')));
      }
    });

    test('lossless codecs are', () {
      expect(stream(AudioCodec.flac, 1411).isLossless, isTrue);
      expect(stream(AudioCodec.flac, 1411).qualityLabel, contains('Lossless'));
    });
  });
}
